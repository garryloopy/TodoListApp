import {
    ScrollView
} from "react-native";

import Task from "./Task";

import { useState } from "react";

export default function TodoList( {styles, tasks} ) {
    const [selectedTasks, setSelectedTasks] = useState([]);

    const handleOnTaskSelect = (task) => {
        if (selectedTasks.includes(task)) {
            setSelectedTasks(
                selectedTasks.filter((currentTask) => currentTask != task)
            )
            return;
        }

        setSelectedTasks(
            [
                ...selectedTasks,
                task
            ]
        )
    }

    return (
        <ScrollView>
            {
                tasks.map(
                    (task) => (
                        <Task styles={styles} 
                              task={task} 
                              key={task}
                              isSelected={selectedTasks.includes(task)}
                              onTaskSelect={handleOnTaskSelect}/>
                    )
                )
            }
        </ScrollView>
    )
}